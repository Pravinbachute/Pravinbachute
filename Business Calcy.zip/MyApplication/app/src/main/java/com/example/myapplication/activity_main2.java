package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class activity_main2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        EditText editTextWeightPerPiece = findViewById(R.id.editTextWeightPerPiece);
        EditText editTextPieces = findViewById(R.id.editTextPieces);
        Button buttonPiecesToWeight = findViewById(R.id.buttonPiecesToWeight);
        TextView textViewWeightResult = findViewById(R.id.textViewWeightResult);

        EditText editTextWeight = findViewById(R.id.editTextWeight);
        Button buttonWeightToPieces = findViewById(R.id.buttonWeightToPieces);
        TextView textViewPiecesResult = findViewById(R.id.textViewPiecesResult);

        buttonPiecesToWeight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String weightPerPieceText = editTextWeightPerPiece.getText().toString();
                String piecesText = editTextPieces.getText().toString();

                if (!weightPerPieceText.isEmpty() && !piecesText.isEmpty()) {
                    double weightPerPiece = Double.parseDouble(weightPerPieceText);
                    int pieces = Integer.parseInt(piecesText);
                    double weight = pieces * weightPerPiece / 1000; // Convert grams to kilograms
                    textViewWeightResult.setText("Weight: " + weight + " kg");
                } else {
                    textViewWeightResult.setText("Invalid input");
                }
            }
        });

        buttonWeightToPieces.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String weightPerPieceText = editTextWeightPerPiece.getText().toString();
                String weightText = editTextWeight.getText().toString();

                if (!weightPerPieceText.isEmpty() && !weightText.isEmpty()) {
                    double weightPerPiece = Double.parseDouble(weightPerPieceText);
                    double weight = Double.parseDouble(weightText) * 1000; // Convert kilograms to grams
                    int pieces = (int) (weight / weightPerPiece);
                    textViewPiecesResult.setText("Pieces: " + pieces);
                } else {
                    textViewPiecesResult.setText("Invalid input");
                }
            }
        });
    }
}
