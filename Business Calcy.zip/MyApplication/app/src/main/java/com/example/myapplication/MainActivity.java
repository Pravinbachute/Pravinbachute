package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private static final int SPLASH_DISPLAY_LENGTH = 3000; // 1000 milliseconds (1 second)

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Handler to start the MainActivity after the splash screen is shown for 1 second
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent mainIntent = new Intent(MainActivity.this, activity_main2.class);
                startActivity(mainIntent);
                finish(); // Close the SplashActivity so the user cannot return to it
            }
        }, SPLASH_DISPLAY_LENGTH);
    }
}
